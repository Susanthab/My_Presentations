
/*
Ways to explore latch info using DMVs
*/


-- Review the BUF-Latches
SELECT * FROM sys.dm_os_wait_stats
WHERE wait_type LIKE 'PAGELATCH%'
GO

-- Review the IO-Latches
SELECT * FROM sys.dm_os_wait_stats
WHERE wait_type LIKE 'PAGEIOLATCH%'
GO

-- Review the Non-BUF Latches
SELECT * FROM sys.dm_os_wait_stats
WHERE wait_type LIKE 'LATCH%'
GO

-- Deailed breakdown of the Non-BUF Latches
SELECT * FROM sys.dm_os_latch_stats
GO