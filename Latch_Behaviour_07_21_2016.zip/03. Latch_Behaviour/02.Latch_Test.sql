USE master
GO

--===============================================
--Part I
--Latch behaviour in Traditional disk based table
--===============================================

-- Create new database[Order]
CREATE DATABASE LatchTestDB
GO

USE LatchTestDB
GO

-- Create table for Orders
CREATE TABLE [Order]
(
	OrderID INT IDENTITY(1, 1) NOT NULL PRIMARY KEY CLUSTERED,
	CustomerID INT NOT NULL,
	ProductID INT NOT NULL,
	Quantity INT NOT NULL,
	Price DECIMAL(18, 2) NOT NULL
)
GO

-- Create a stored procedure that inserts 10000 new orders
CREATE PROCEDURE CreateOrder
AS
BEGIN
	DECLARE @i INT = 0
	WHILE (@i < 10000)
	BEGIN		
		INSERT INTO [Order] (CustomerID, ProductID, Quantity, Price)
		VALUES
		(
			1, 
			1, 
			1,
			20.45
		)

		SET @i += 1
	END
END
GO

-- Clears the wait statistics
DBCC SQLPERF ('sys.dm_os_wait_stats', CLEAR)
GO

-- Execute the stored procedure with 100 parallel users
-- ostress.exe -S"localhost\sql2016" -Q"SELECT @@Servername" 
-- ostress.exe -S"localhost\sql2016" -Q"EXEC LatchTestDB.dbo.CreateOrder" -n100 -r1 -q

--TRUNCATE TABLE [Order]

-- Retrieve all current executing requests
SELECT wait_type, * FROM sys.dm_exec_requests
WHERE session_id > 50
GO

-- 1 000 000 records!
SELECT COUNT(*) FROM [Order]
GO

-- Review the Page Latch wait types and WRITELOG
SELECT * FROM sys.dm_os_wait_stats
WHERE wait_type LIKE 'PAGELATCH%' OR wait_type = 'WRITELOG'
GO

-- Let's create a traditional disk-based table
CREATE TABLE [Order2]
(
	OrderID UNIQUEIDENTIFIER NOT NULL PRIMARY KEY CLUSTERED,
	CustomerID INT NOT NULL,
	ProductID INT NOT NULL,
	Quantity INT NOT NULL,
	Price DECIMAL(18, 2) NOT NULL
)
GO

-- Create a stored procedure that inserts 10000 new orders
CREATE PROCEDURE CreateOrder2
AS
BEGIN
	DECLARE @i INT = 0
	WHILE (@i < 10000)
	BEGIN		
		INSERT INTO [Order2] (OrderID, CustomerID, ProductID, Quantity, Price)
		VALUES
		(
			NEWID(),
			1, 
			1, 
			1,
			20.45
		)

		SET @i += 1
	END
END
GO

-- Clears the wait statistics
DBCC SQLPERF ('sys.dm_os_wait_stats', CLEAR)
GO

-- Execute the stored procedure with 100 parallel users
-- ostress.exe -S"localhost\sql2016" -Q"EXEC LatchTestDB.dbo.CreateOrder2" -n100 -r1 -q

-- Retrieve all current executing requests
SELECT wait_type, * FROM sys.dm_exec_requests
WHERE session_id > 50
GO

-- 1 000 000 records!
SELECT COUNT(*) FROM [Order2]
GO

-- Review the Page Latch wait types and WRITELOG
SELECT * FROM sys.dm_os_wait_stats
WHERE wait_type LIKE 'PAGELATCH%' OR wait_type = 'WRITELOG'
GO













--===============================================
--Part II
--Latch behaviour in Memory based table
--===============================================

--Add MEMORY_OPTIMIZED_DATA filegroup to the database.
ALTER DATABASE LatchTestDB
ADD FILEGROUP InMemoryOLTPFileGroup CONTAINS MEMORY_OPTIMIZED_DATA
GO

-- Add a new file to the previous created file group
ALTER DATABASE LatchTestDB ADD FILE
(
	NAME = N'InMemoryOLTPContainer', 
	FILENAME = N'C:\SQL2016\MSSQL13.SQL2016\MSSQL\Data\InMemoryOLTPContainer'
)
TO FILEGROUP [InMemoryOLTPFileGroup]
GO

-- Let's create a new Memory Optimized Table
CREATE TABLE OrdersInMemory
(
	OrderID INT IDENTITY (1, 1) NOT NULL,
	CustomerID INT NOT NULL,
	ProductID INT NOT NULL,
	Quantity INT NOT NULL,
	Price DECIMAL(18, 2) NOT NULL
	CONSTRAINT chk_PrimaryKey PRIMARY KEY NONCLUSTERED HASH (OrderID) WITH (BUCKET_COUNT = 1048576) 
) WITH (MEMORY_OPTIMIZED = ON)
GO

-- Create a stored procedure that inserts continuously new orders
CREATE PROCEDURE CreateOrdersInMemory
AS
BEGIN
	DECLARE @i INT = 0
	WHILE (@i < 10000)
	BEGIN		
		INSERT INTO OrdersInMemory (CustomerID, ProductID, Quantity, Price)
		VALUES
		(
			1, 
			1, 
			1,
			20.45
		)

		SET @i += 1
	END
END
GO

-- Clears the wait statistics
DBCC SQLPERF ('sys.dm_os_wait_stats', CLEAR)
GO

-- Execute the stored procedure with 100 parallel users
-- ostress.exe -S"localhost\sql2016" -Q"EXEC LatchTestDB.dbo.CreateOrdersInMemory" -n100 -r1 -q

-- Retrieve all current executing requests
SELECT wait_type, * FROM sys.dm_exec_requests
WHERE session_id > 50
GO

-- 1 000 000 records!
SELECT COUNT(*) FROM OrdersInMemory
GO

-- Review the Page Latch wait types and WRITELOG
SELECT * FROM sys.dm_os_wait_stats
WHERE wait_type LIKE 'PAGELATCH%' OR wait_type = 'WRITELOG'
GO

-- Drop the stored procedure
DROP PROCEDURE CreateOrdersInMemory
GO

-- Create a stored procedure that inserts continuously new orders
CREATE PROCEDURE CreateOrdersInMemory
WITH NATIVE_COMPILATION, SCHEMABINDING, EXECUTE AS OWNER
AS
BEGIN
	ATOMIC WITH
	(
		TRANSACTION ISOLATION LEVEL = SNAPSHOT, LANGUAGE = 'us_english'
	)

	DECLARE @i INT = 0

	WHILE (@i < 10000)
	BEGIN
		INSERT INTO dbo.OrdersInMemory (CustomerID, ProductID, Quantity, Price)
		VALUES
		(
			1, 
			1, 
			1,
			20.45
		)

		SET @i += 1
	END
END
GO

-- Clears the wait statistics
DBCC SQLPERF ('sys.dm_os_wait_stats', CLEAR)
GO

-- Execute the stored procedure with 100 parallel users
-- ostress.exe -S"localhost\sql2016" -Q"EXEC LatchTestDB.dbo.CreateOrdersInMemory" -n100 -r1 -q

-- Retrieve all current executing requests
SELECT wait_type, * FROM sys.dm_exec_requests
WHERE session_id > 50
GO

SELECT COUNT(*) FROM OrdersInMemory
GO

-- Review the Page Latch wait types and WRITELOG
SELECT * FROM sys.dm_os_wait_stats
WHERE wait_type LIKE 'PAGELATCH%' OR wait_type = 'WRITELOG'
GO

-- Clean up
USE master
GO

DROP DATABASE LatchTestDB
GO

--Clear InMemory FG location